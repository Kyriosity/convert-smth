# WPF Guidelines
## MVVM
Is so established pattern in WPF that it's rather a symbiose of it.

### Pitfalls
+ ViewModel shall not know about View, but e.g. colors declarations in ViewModel are common. View can't be even a view - can be a communication layer for disabled. The rule: when developing ViewModel, think that folks with disabled sight can be users.
+ Model is NOT data. It's abstraction of data **and business**. Data may come from databases, pipes, services, maybe hardcoded or randomized. Maybe persistent and not.&nbsp;&nbsp;<sup>**_mvw**</sup>

&nbsp;&nbsp;<sup>**_mvw**</sup><sub>&nbsp;&nbsp;Google team suggested even a better concept/name for its Angular - MVW. *Model-View-Whatever*.</sub>

## Converters
When referring back to pitalls, converters can't give colors, even themes. It must be 'info', 'alarm', 'warning', and the view shall take care how to render them.

### Naming and parametrization
Now consider two paired converters: `RunToBoolean` and `InvertedRunToBoolean`.
What's wrong?\
A) Readability: the name shall be `IsRunning`.\
B) Converters may have parameters, which can be set just in XAML, e.g. `inverted=true`

So, the only one `IsRunning` converter. With more comprising return values as boolean, more than two converter declarations can be spared.


## XAML

### Target Null and Fallback
TargetNullValue=0, FallbackValue=10