# Schemes of UValues
**ATTENTION!!! This is a mere concept at the moment and NOT under development**

Si System, US avia, Britisch imperial, euro etc/
