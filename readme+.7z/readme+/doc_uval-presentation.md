# Presentation of UValues

### Labels

### Angular pipe
The library provides an angular pipe for both conversion and presentation of UValues.

[Read more about pipe](doc_uval-pipe.md)

### Sorting
Is so far not a part of the library but ...