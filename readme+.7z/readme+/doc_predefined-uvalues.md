# Predefined UValues

**ATTENTION!!! This is a mere concept at the moment and NOT under development**

The physical world as well as the physics science has myriads of fixed values, which could be dealt from the library.

The challenge here is that it shall support various units.

Plank's constant

TheEarth.Mass.Tonne


Water.Boiling

H0Scale